public class Player
{
     public int health =5;
    public int x,y;
    private int score = 0;
    public string name = "Player"; 
    

    public Player() 
    {
        Random rnd = new Random();
        health = 10;
        x = rnd.Next(0,10);
        y = rnd.Next(0,10);

       
        
    }
    public void Yay()
    {
        Console.WriteLine("YAY");
    }

}