﻿

class Entry 
{

static Player player1 = new Player();
static Player player2 = new Player(); 
static char[] horizontalStripe= new char[10]{'|','|','|','|','|','|','|','|','|','|'};
static List<char[]> stripeCollection = new List<char[]>(); 
static bool playerOneTurn = true;




static void Display()
{

for(int i=0; i <stripeCollection.Count; i++)
{
    char[] player2Line= new char[10]{'|','|','|','|','|','|','|','|','|','|'};
    char[] player1Line= new char[10]{'|','|','|','|','|','|','|','|','|','|'};
    if(i == player1.y)
            {
               
                for(int j = 0; j<10; j++)
                {
                    
                    if(j== player1.x)
                    {
                        player1Line[j] = '@';
                    }
                }
            }
            if(i == player2.y)
            {
               
                for(int j = 0; j<10; j++)
                {
                    
                    if(j== player2.x)
                    {
                        player2Line[j] = '*';
                    }
                }
            }

 
    if(i == player2.y)
            {
                string playerWhole= new string(player2Line);
                Console.WriteLine(playerWhole);
            }else if ( i== player1.y)
            {
                string playerWhole= new string(player1Line);
                Console.WriteLine(playerWhole);
            }else
            {
    string wholeLine= new string(stripeCollection[i]);
   
    Console.WriteLine(wholeLine);
            }
            
           
}

//Console.WriteLine(player1.x +" " + player1.y);
//Console.WriteLine(player2.x +" " + player2.y);
 if (playerOneTurn)
            {
                Player1Move();
            }else
            {
                Player2Move();
            }
}
static void EntryWelcome()
    {


for(int i=0;i<10;i++)
        {
            stripeCollection.Add(horizontalStripe);
        }

        
            Console.WriteLine("Choose Player1 name");
            string name = Console.ReadLine() ?? string.Empty;
            if(name == String.Empty)
        {
            name = "Player1";
        }
            player1.name = name;
        
         Console.WriteLine("Choose Player2 name");
            string name2 = Console.ReadLine() ?? string.Empty;
            if(name2 == String.Empty)
        {
            name2 = "Player1";
        }
            player2.name = name2;
            
            
    }
    static void Player1Move()
    {
        playerOneTurn = false;
        Console.WriteLine(player1.name + "'s" + " "+ "Turn");
        Console.WriteLine("Pick a direction");
        string dir = Console.ReadLine()?? string.Empty;
        if(dir == "a" || dir == "A")
        {
            player1.x -= 1;
            if(player1.x < 0)
            {
                player1.x =9;
            }
        }else if (dir == "d" || dir == "D")
        {
            player1.x += 1;
            if(player1.x > 9)
            {
                player1.x =0;
            }
        }else if (dir == "w" || dir == "W")
        {
            player1.y -= 1;
            if(player1.y < 0)
            {
                player1.y =9;
            }
        }else if (dir == "s" || dir == "S")
        {
            player1.y += 1;
            if(player1.y > 9)
            {
                player1.y =0;
            }
        }else
        {
            Player1Move();
        }
        if(player1.x == player2.x && player1.y == player2.y)
        {
            player2.TakeDamage(1);
            if(player2.DeathCheck)
            {
                Console.WriteLine(player1.name + " " +"has won");
               Environment.Exit(0);
             
               
            }
            Console.WriteLine(player2.health);
            Random rnd = new Random();
            player2.x = rnd.Next(0,10);
            player2.y = rnd.Next(0,10);
            
        }
        Display();
    }
    static void Player2Move()
    {
        playerOneTurn = true;
          Console.WriteLine(player2.name + "'s" + " "+ "Turn");
        Console.WriteLine("Pick a direction");
        string dir = Console.ReadLine() ?? string.Empty;
        if(dir == "a" || dir == "A")
        {
            player2.x -= 1;
            if(player2.x < 0)
            {
                player2.x =9;
            }
        }else if (dir == "d" || dir == "D")
        {
            player2.x += 1;
            if(player2.x > 9)
            {
                player2.x =0;
            }
        }else if (dir == "w" || dir == "W")
        {
            player2.y -= 1;
            if(player2.y < 0)
            {
                player2.y =9;
            }
        }else if (dir == "s" || dir == "S")
        {
            player2.y += 1;
            if(player2.y > 9)
            {
                player2.y =0;
            }
        }else
        {
            Player2Move();
        }
        if(player2.x == player1.x && player2.y == player1.y)
        {
            player1.TakeDamage(1);
            if(player1.DeathCheck)
            {
                Console.WriteLine(player2.name + " " +"has won");
              Environment.Exit(0);

            }
            Random rnd = new Random();
            player1.x = rnd.Next(0,10);
            player1.y = rnd.Next(0,10);
            Console.WriteLine(player1.health);
        }
        Display();
    }

static void Main(string[] args)
    {
       
        Console.WriteLine("Welcome To 2 Player Game");
        EntryWelcome();
        Display();
        
    }

}
